<footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong>Copyright &copy;  <a href="http://www.aunsolutions.com/">Aun Solutions</a>.</strong> All rights
    reserved.
  </footer>