﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('devtools','sk',{devTools:{title:'Informácie o prvku',dialogName:'Názov okna dialógu',tabName:'Názov záložky',elementId:'ID prvku',elementType:'Typ prvku'}});
